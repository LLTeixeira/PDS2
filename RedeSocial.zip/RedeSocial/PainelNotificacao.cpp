#include "Painel.hpp"
#include <string>
#include <iostream>
#include <stack>


void PainelNotificacao::printPainel(){
    // TODO: Criar printPainel (Painel Notificação)
    std::cout << "========================" << std::endl;
    std::cout << "| Painel Notificação:" << std::endl;
    std::cout << "| [0] Sair" << std::endl;
    std::cout << "========================" << std::endl;
    std::cout << "|> Código: ";
}

void PainelNotificacao::exibir(RedeSocial* rede_social){
    // TODO: Criar exibir PainelNotificacao
}